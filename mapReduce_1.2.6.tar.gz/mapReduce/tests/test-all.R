
library(testthat) 
library(mapReduce)

test_package("mapReduce") 

